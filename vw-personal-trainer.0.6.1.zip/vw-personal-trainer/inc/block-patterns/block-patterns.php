<?php
/**
 * VW Personal Trainer: Block Patterns
 *
 * @package VW Personal Trainer
 * @since   1.0.0
 */

/**
 * Register Block Pattern Category.
 */
if ( function_exists( 'register_block_pattern_category' ) ) {

	register_block_pattern_category(
		'vw-personal-trainer',
		array( 'label' => __( 'VW Personal Trainer', 'vw-personal-trainer' ) )
	);
}

/**
 * Register Block Patterns.
 */
if ( function_exists( 'register_block_pattern' ) ) {
	register_block_pattern(
		'vw-personal-trainer/banner-section',
		array(
			'title'      => __( 'Banner Section', 'vw-personal-trainer' ),
			'categories' => array( 'vw-personal-trainer' ),
			'content'    => "<!-- wp:cover {\"url\":\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner.png\",\"id\":8209,\"align\":\"full\",\"className\":\"banner\"} -->\n<div class=\"wp-block-cover alignfull has-background-dim banner\" style=\"background-image:url(" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/banner.png)\"><div class=\"wp-block-cover__inner-container\"><!-- wp:columns {\"align\":\"wide\"} -->\n<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"25%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:25%\"></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"verticalAlignment\":\"center\",\"width\":\"50%\",\"className\":\"banner-middle-content\"} -->\n<div class=\"wp-block-column is-vertically-aligned-center banner-middle-content\" style=\"flex-basis:50%\"><!-- wp:heading {\"textAlign\":\"center\",\"level\":1,\"style\":{\"typography\":{\"fontSize\":45}}} -->\n<h1 class=\"has-text-align-center\" style=\"font-size:45px\">LOREM IPSUM IS SIMPLY DUMMY TEXT </h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph {\"align\":\"center\",\"className\":\"text-center\",\"style\":{\"typography\":{\"fontSize\":15}}} -->\n<p class=\"has-text-align-center text-center\" style=\"font-size:15px\">&nbsp;Lorem Ipsum has been the industrys standard. &nbsp;Lorem Ipsum has been the industrys standard.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {\"align\":\"center\"} -->\n<div class=\"wp-block-buttons aligncenter\"><!-- wp:button {\"style\":{\"color\":{\"background\":\"#a72dd9\"}},\"textColor\":\"white\"} -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" style=\"background-color:#a72dd9\">READ MORE</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"25%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:25%\"></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div></div>\n<!-- /wp:cover -->",
		)
	);

	register_block_pattern(
		'vw-personal-trainer/courses-section',
		array(
			'title'      => __( 'Courses Section', 'vw-personal-trainer' ),
			'categories' => array( 'vw-personal-trainer' ),
			'content'    => "<!-- wp:cover {\"overlayColor\":\"white\",\"align\":\"wide\",\"className\":\"courses-section m-0\"} -->\n<div class=\"wp-block-cover alignwide has-white-background-color has-background-dim courses-section m-0\"><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"textAlign\":\"left\",\"className\":\"mb-5\",\"style\":{\"color\":{\"text\":\"#30374c\"},\"typography\":{\"fontSize\":35}}} -->\n<h2 class=\"has-text-align-left mb-5 has-text-color\" style=\"color:#30374c;font-size:35px\">POPULAR COURSES</h2>\n<!-- /wp:heading -->\n\n<!-- wp:columns {\"align\":\"wide\",\"className\":\"m-0\"} -->\n<div class=\"wp-block-columns alignwide m-0\"><!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column {\"width\":\"33.33%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"><!-- wp:image {\"id\":8211,\"sizeSlug\":\"large\",\"linkDestination\":\"media\",\"className\":\"is-style-rounded\"} -->\n<figure class=\"wp-block-image size-large is-style-rounded\"><img src=\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/courses-1.png\" alt=\"\" class=\"wp-image-8211\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"66.66%\",\"className\":\"ml-3\"} -->\n<div class=\"wp-block-column ml-3\" style=\"flex-basis:66.66%\"><!-- wp:heading {\"textAlign\":\"left\",\"level\":3,\"className\":\"mb-3\",\"style\":{\"color\":{\"text\":\"#30374c\"},\"typography\":{\"fontSize\":25}}} -->\n<h3 class=\"has-text-align-left mb-3 has-text-color\" style=\"color:#30374c;font-size:25px\">COURSES TITLE 1</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph {\"align\":\"left\",\"className\":\"mb-3\",\"style\":{\"color\":{\"text\":\"#7a7e89\"},\"typography\":{\"fontSize\":14}}} -->\n<p class=\"has-text-align-left mb-3 has-text-color\" style=\"color:#7a7e89;font-size:14px\">Lorem Ipsum has been the industrys standard. Lorem Ipsum has been the industrys standard.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {\"align\":\"left\",\"className\":\"m-0 p-0\"} -->\n<div class=\"wp-block-buttons alignleft m-0 p-0\"><!-- wp:button {\"style\":{\"color\":{\"background\":\"#a72dd9\"}},\"textColor\":\"white\"} -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" style=\"background-color:#a72dd9\">READ MORE</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div>\n<!-- /wp:column -->\n\n<!-- wp:column -->\n<div class=\"wp-block-column\"><!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column {\"width\":\"33.33%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"><!-- wp:image {\"id\":8212,\"sizeSlug\":\"large\",\"linkDestination\":\"media\",\"className\":\"is-style-rounded\"} -->\n<figure class=\"wp-block-image size-large is-style-rounded\"><img src=\"" . esc_url(get_template_directory_uri()) . "/inc/block-patterns/images/courses-2.png\" alt=\"\" class=\"wp-image-8212\"/></figure>\n<!-- /wp:image --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"66.66%\",\"className\":\"ml-3\"} -->\n<div class=\"wp-block-column ml-3\" style=\"flex-basis:66.66%\"><!-- wp:heading {\"textAlign\":\"left\",\"level\":3,\"className\":\"mb-3\",\"style\":{\"color\":{\"text\":\"#30374c\"},\"typography\":{\"fontSize\":25}}} -->\n<h3 class=\"has-text-align-left mb-3 has-text-color\" style=\"color:#30374c;font-size:25px\">COURSES TITLE 2</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph {\"align\":\"left\",\"className\":\"mb-3\",\"style\":{\"color\":{\"text\":\"#7a7e89\"},\"typography\":{\"fontSize\":14}}} -->\n<p class=\"has-text-align-left mb-3 has-text-color\" style=\"color:#7a7e89;font-size:14px\">Lorem Ipsum has been the industrys standard. Lorem Ipsum has been the industrys standard.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons {\"align\":\"left\",\"className\":\"m-0 p-0\"} -->\n<div class=\"wp-block-buttons alignleft m-0 p-0\"><!-- wp:button {\"style\":{\"color\":{\"background\":\"#a72dd9\"}},\"textColor\":\"white\"} -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" style=\"background-color:#a72dd9\">READ MORE</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div></div>\n<!-- /wp:cover -->",
		)
	);
}