# web-sample-project_1.0
The first web tamplate on GitHub by me!
From this project I'm starting my journey to the world of Web Developers..
