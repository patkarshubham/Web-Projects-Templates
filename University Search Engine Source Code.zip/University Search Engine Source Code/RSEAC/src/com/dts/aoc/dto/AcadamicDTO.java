package com.dts.aoc.dto;

public class AcadamicDTO {

	private String loginname;
	private int yearofpass;
	private int yearofjoining;
	private String profession;
	private String rollno;
	/**
	 * @return the loginname
	 */
	public String getLoginname() {
		return loginname;
	}
	/**
	 * @param loginname the loginname to set
	 */
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	/**
	 * @return the yearofpass
	 */
	public int getYearofpass() {
		return yearofpass;
	}
	/**
	 * @param yearofpass the yearofpass to set
	 */
	public void setYearofpass(int yearofpass) {
		this.yearofpass = yearofpass;
	}
	/**
	 * @return the yearofjoining
	 */
	public int getYearofjoining() {
		return yearofjoining;
	}
	/**
	 * @param yearofjoining the yearofjoining to set
	 */
	public void setYearofjoining(int yearofjoining) {
		this.yearofjoining = yearofjoining;
	}
	/**
	 * @return the profession
	 */
	public String getProfession() {
		return profession;
	}
	/**
	 * @param profession the profession to set
	 */
	public void setProfession(String profession) {
		this.profession = profession;
	}
	/**
	 * @return the rollno
	 */
	public String getRollno() {
		return rollno;
	}
	/**
	 * @param rollno the rollno to set
	 */
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
}
